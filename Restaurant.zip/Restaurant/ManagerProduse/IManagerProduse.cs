﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ManagerProduse
{
    public interface IManagerProduse
    {
        int GetNrProduse();
        string[] ReturnAll();

        void AddProduct(string name);

        void DeleteProduct(string name);
    }
}
