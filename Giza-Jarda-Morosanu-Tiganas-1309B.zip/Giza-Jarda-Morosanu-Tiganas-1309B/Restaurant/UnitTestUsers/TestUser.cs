﻿/************************************************************
 *                                                          *
 *   File: Form1.cs                                         *
 *   Copyright: (c) 2021, Țiganaș Ștefan-Gabriel            *
 *   Description: Aplicatie de tip food delivery            *
 *                                                          *
 *                                                          *
 *                                                          *
 *                                                          *
 ************************************************************/

using ProxyUser;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace UnitTestUsers
{
    [TestClass]
    public class TestUsers
    {

        [TestMethod]
        public void TestMethod1()
        {
            Proxy user = new Proxy();
            Assert.AreEqual(true, user.Inregistrare("user", "user"));
        }

        [TestMethod]
        public void TestMethod2()
        {
            Proxy user = new Proxy();
            Assert.AreEqual(true, user.Inregistrare("stefan", "stefan"));
        }

        [TestMethod]
        public void TestMethod3()
        {
            Proxy user = new Proxy();
            Assert.AreEqual(false, user.Inregistrare("Stefan", "stefan"));
        }

        [TestMethod]
        public void TestMethod4()
        {
            Proxy user = new Proxy();
            Assert.AreEqual(true, user.Inregistrare("radu ", "radu"));
        }

        [TestMethod]
        public void TestMethod5()
        {
            Proxy user = new Proxy();
            Assert.AreEqual(false, user.Inregistrare("elisa,", "elisa"));
        }

        [TestMethod]
        public void TestMethod6()
        {
            Proxy user = new Proxy();
            Assert.AreEqual(false, user.Inregistrare(" david", " david"));
        }

        [TestMethod]
        public void TestMethod7()
        {
            Proxy user = new Proxy();
            Assert.AreEqual(false, user.Inregistrare("username", "password"));
        }

        [TestMethod]
        public void TestMethod8()
        {
            Proxy user = new Proxy();
            Assert.AreEqual(true, user.Inregistrare("Username", "Password"));
        }

        [TestMethod]
        public void TestMethod9()
        {
            Proxy user = new Proxy();
            Assert.AreEqual(true, user.Inregistrare("david", "david"));
        }

        [TestMethod]
        public void TestMethod10()
        {
            Proxy user = new Proxy();
            Assert.AreEqual(false, user.Inregistrare("radu", "elisa"));
        }

        [TestMethod]
        public void TestMethod11()
        {
            Proxy user = new Proxy();
            Assert.AreEqual(false, user.Inregistrare("DAVID", "DAVID"));
        }

        [TestMethod]
        public void TestMethod12()
        {
            Proxy user = new Proxy();
            Assert.AreEqual(false, user.Inregistrare("elisa", "elisa"));
        }

        [TestMethod]
        public void TestMethod13()
        {
            Proxy user = new Proxy();
            Assert.AreEqual(false, user.Inregistrare("Radu", "Radu"));
        }

        [TestMethod]
        public void TestMethod14()
        {
            Proxy user = new Proxy();
            Assert.AreEqual(true, user.Inregistrare("user.user", "user.password"));
        }

        [TestMethod]
        public void TestMethod15()
        {
            Proxy user = new Proxy();
            Assert.AreEqual(true, user.Inregistrare("radu", "radu"));
        }

        [TestMethod]
        public void TestMethod16()
        {
            Proxy user = new Proxy();
            Assert.AreEqual(false, user.Inregistrare("curier", "curier"));
        }

    }
}
