﻿/************************************************************
 *                                                          *
 *   File: Form1.cs                                         *
 *   Copyright: (c) 2021, Gîza David-Noel                   *
 *   Description: Aplicatie de tip food delivery            *
 *                                                          *
 *                                                          *
 *                                                          *
 *                                                          *
 ************************************************************/

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProxyUser
{
    public class Proxy
    {
        /// <summary>
        /// Clasa care se ocupa de autentificarea clientilor aplicatiei
        /// </summary>
        private List<Client> _clienti;
        private const string Folder = "Clienti\\";

        /// <summary>
        /// Structura cu campurile "Utilizator" si "Parola" specifice fiecarui cont 
        /// </summary>
        public struct Client
        {
            public readonly string Utilizator;
            public readonly string Parola;

            /// <summary>
            /// Constructor pentru crearea contului
            /// </summary>
            /// <param name="username">Numele utilizatorului</param>
            /// <param name="password">Parola contului</param>

            public Client(string utilizator, string parola)
            {
                Utilizator = utilizator;
                Parola = parola;
            }
        }

        /// <summary>
        /// Constructorul clasei care are rolul de a actualiza lista conturilor din fisierul text clienti
        /// </summary>
        public Proxy()
        {
            try
            {
                _clienti = new List<Client>();
                StreamReader reader = new StreamReader("E:\\ELISA\\AN III\\SEM II\\IP\\proiect_git\\V4\\Restaurant\\clienti.txt");
                string line;
                while ((line = reader.ReadLine()) != null)
                {
                    string[] clienti = line.Split(',');
                    Client user = new Client(clienti[0], clienti[1]);
                    _clienti.Add(user);
                }
                reader.Close();

            }
            catch (Exception exceptie)
            {
                Console.WriteLine(exceptie);
            }
        }

        /// <summary>
        /// Metoda de înregistrare în aplicție
        /// </summary>
        /// <param name="utilizator"></param>
        /// <param name="parola"></param>
        /// <returns>True in cazul in care numele si parola clientului sunt existente, False in caz contrar</returns>
        public bool Inregistrare(string utilizator, string parola)
        {
            foreach (Client u in _clienti)
            {
                if (u.Utilizator.Equals(utilizator) && u.Parola.Equals(parola))
                {
                    return true;
                }
            }
            return false;
        }
    }
}
