﻿/*****************************************************************
 *                                                               *
 *   File: Form1.cs                                              *
 *   Copyright: (c) 2021, Jardă Maria-Elisabeta                  *
 *   Description: Aplicatie de tip food delivery-Manager Produse *
 *                                                               *
 *                                                               *
 *                                                               *
 *                                                               *
 *****************************************************************/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ManagerProduse
{
    /// <summary>
    /// Interfata pentru managementul produselor
    /// </summary>
    public interface IManagerProduse
    {
        /// <summary>
        /// Metoda care returneaza numarul de produse din meniul restaurantului
        /// </summary>
        /// <returns>Numarul produselor din lista</returns>
        int GetNrProduse();

        /// <summary>
        /// 
        ///Metoda care returneaza lista cu numele produselor dintr-un restaurant
        /// </summary>
        /// <returns>Lista cu numele produselor dintr-un restaurant</returns>
        string[] ReturnAll();

    }
}
