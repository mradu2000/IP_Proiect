﻿
namespace Restaurant
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.Parola_Box = new System.Windows.Forms.TextBox();
            this.Username_Box = new System.Windows.Forms.TextBox();
            this.button_Exit = new System.Windows.Forms.Button();
            this.button_Help = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.panel_Login = new System.Windows.Forms.Panel();
            this.button_Login = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.button_KFC = new System.Windows.Forms.Button();
            this.panel_KFC = new System.Windows.Forms.Panel();
            this.panel_MC = new System.Windows.Forms.Panel();
            this.panel_MM = new System.Windows.Forms.Panel();
            this.panel_TB = new System.Windows.Forms.Panel();
            this.button_backToMainTB = new System.Windows.Forms.Button();
            this.button_AddTB = new System.Windows.Forms.Button();
            this.button_StergeTB = new System.Windows.Forms.Button();
            this.button_PlaseazaTB = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.richTextBox_TB = new System.Windows.Forms.RichTextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.comboBox_TB = new System.Windows.Forms.ComboBox();
            this.label12 = new System.Windows.Forms.Label();
            this.button_backToMainMM = new System.Windows.Forms.Button();
            this.button_AddMM = new System.Windows.Forms.Button();
            this.button_StergeMM = new System.Windows.Forms.Button();
            this.button_PlaseazaMM = new System.Windows.Forms.Button();
            this.label16 = new System.Windows.Forms.Label();
            this.richTextBox_MM = new System.Windows.Forms.RichTextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.comboBox_MM = new System.Windows.Forms.ComboBox();
            this.label18 = new System.Windows.Forms.Label();
            this.button_backToMainMC = new System.Windows.Forms.Button();
            this.button_AddMC = new System.Windows.Forms.Button();
            this.button_StergeMC = new System.Windows.Forms.Button();
            this.button_PlaseazaMC = new System.Windows.Forms.Button();
            this.label13 = new System.Windows.Forms.Label();
            this.richTextBox_MC = new System.Windows.Forms.RichTextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.comboBox_MC = new System.Windows.Forms.ComboBox();
            this.label15 = new System.Windows.Forms.Label();
            this.button_backToMain = new System.Windows.Forms.Button();
            this.button_AddKfc = new System.Windows.Forms.Button();
            this.button_StergeKFC = new System.Windows.Forms.Button();
            this.button_PlaseazaKfc = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.richTextBox_KFC = new System.Windows.Forms.RichTextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.comboBox_KFC = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.button_MM = new System.Windows.Forms.Button();
            this.button_MC = new System.Windows.Forms.Button();
            this.button_TB = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.panel_Main = new System.Windows.Forms.Panel();
            this.panel_Login.SuspendLayout();
            this.panel_KFC.SuspendLayout();
            this.panel_MC.SuspendLayout();
            this.panel_MM.SuspendLayout();
            this.panel_TB.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.panel_Main.SuspendLayout();
            this.SuspendLayout();
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Britannic Bold", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Red;
            this.label4.Location = new System.Drawing.Point(327, 153);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(0, 41);
            this.label4.TabIndex = 8;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(13, 351);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(70, 29);
            this.label3.TabIndex = 6;
            this.label3.Text = "Parola";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(13, 266);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(104, 29);
            this.label2.TabIndex = 5;
            this.label2.Text = "Username";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Impact", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.label1.Location = new System.Drawing.Point(12, 196);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(86, 37);
            this.label1.TabIndex = 4;
            this.label1.Text = "LOGIN";
            // 
            // Parola_Box
            // 
            this.Parola_Box.Location = new System.Drawing.Point(133, 351);
            this.Parola_Box.Margin = new System.Windows.Forms.Padding(4);
            this.Parola_Box.Name = "Parola_Box";
            this.Parola_Box.Size = new System.Drawing.Size(240, 22);
            this.Parola_Box.TabIndex = 3;
            // 
            // Username_Box
            // 
            this.Username_Box.Location = new System.Drawing.Point(133, 272);
            this.Username_Box.Margin = new System.Windows.Forms.Padding(4);
            this.Username_Box.Name = "Username_Box";
            this.Username_Box.Size = new System.Drawing.Size(240, 22);
            this.Username_Box.TabIndex = 2;
            // 
            // button_Exit
            // 
            this.button_Exit.BackColor = System.Drawing.Color.Gainsboro;
            this.button_Exit.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_Exit.Location = new System.Drawing.Point(155, 20);
            this.button_Exit.Margin = new System.Windows.Forms.Padding(4);
            this.button_Exit.Name = "button_Exit";
            this.button_Exit.Size = new System.Drawing.Size(103, 42);
            this.button_Exit.TabIndex = 1;
            this.button_Exit.Text = "Exit";
            this.button_Exit.UseVisualStyleBackColor = false;
            this.button_Exit.Click += new System.EventHandler(this.button_Exit_Click);
            // 
            // button_Help
            // 
            this.button_Help.BackColor = System.Drawing.Color.Gainsboro;
            this.button_Help.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_Help.Location = new System.Drawing.Point(21, 20);
            this.button_Help.Margin = new System.Windows.Forms.Padding(4);
            this.button_Help.Name = "button_Help";
            this.button_Help.Size = new System.Drawing.Size(103, 42);
            this.button_Help.TabIndex = 0;
            this.button_Help.Text = "Help";
            this.button_Help.UseVisualStyleBackColor = false;
            this.button_Help.Click += new System.EventHandler(this.button_Help_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Cambria", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(701, 153);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(272, 40);
            this.label6.TabIndex = 10;
            this.label6.Text = "FOOD DELIVERY";
            // 
            // panel_Login
            // 
            this.panel_Login.Controls.Add(this.button_Login);
            this.panel_Login.Controls.Add(this.label6);
            this.panel_Login.Controls.Add(this.label4);
            this.panel_Login.Controls.Add(this.label3);
            this.panel_Login.Controls.Add(this.label2);
            this.panel_Login.Controls.Add(this.label1);
            this.panel_Login.Controls.Add(this.Parola_Box);
            this.panel_Login.Controls.Add(this.Username_Box);
            this.panel_Login.Controls.Add(this.button_Exit);
            this.panel_Login.Controls.Add(this.button_Help);
            this.panel_Login.Location = new System.Drawing.Point(24, 30);
            this.panel_Login.Margin = new System.Windows.Forms.Padding(4);
            this.panel_Login.Name = "panel_Login";
            this.panel_Login.Size = new System.Drawing.Size(1763, 737);
            this.panel_Login.TabIndex = 11;
            // 
            // button_Login
            // 
            this.button_Login.BackColor = System.Drawing.Color.Gainsboro;
            this.button_Login.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_Login.Location = new System.Drawing.Point(244, 414);
            this.button_Login.Margin = new System.Windows.Forms.Padding(4);
            this.button_Login.Name = "button_Login";
            this.button_Login.Size = new System.Drawing.Size(131, 42);
            this.button_Login.TabIndex = 11;
            this.button_Login.Text = "LOGIN";
            this.button_Login.UseVisualStyleBackColor = false;
            this.button_Login.Click += new System.EventHandler(this.button_Login_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Algerian", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label7.Location = new System.Drawing.Point(579, 326);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(501, 34);
            this.label7.TabIndex = 0;
            this.label7.Text = "Alege restaurantul favorit";
            // 
            // button_KFC
            // 
            this.button_KFC.Location = new System.Drawing.Point(169, 298);
            this.button_KFC.Margin = new System.Windows.Forms.Padding(4);
            this.button_KFC.Name = "button_KFC";
            this.button_KFC.Size = new System.Drawing.Size(133, 62);
            this.button_KFC.TabIndex = 1;
            this.button_KFC.Text = "KFC";
            this.button_KFC.UseVisualStyleBackColor = true;
            this.button_KFC.Click += new System.EventHandler(this.button_KFC_Click);
            // 
            // panel_KFC
            // 
            this.panel_KFC.Controls.Add(this.button_backToMain);
            this.panel_KFC.Controls.Add(this.button_AddKfc);
            this.panel_KFC.Controls.Add(this.button_StergeKFC);
            this.panel_KFC.Controls.Add(this.button_PlaseazaKfc);
            this.panel_KFC.Controls.Add(this.label9);
            this.panel_KFC.Controls.Add(this.richTextBox_KFC);
            this.panel_KFC.Controls.Add(this.label8);
            this.panel_KFC.Controls.Add(this.comboBox_KFC);
            this.panel_KFC.Controls.Add(this.label5);
            this.panel_KFC.Location = new System.Drawing.Point(25, 5);
            this.panel_KFC.Margin = new System.Windows.Forms.Padding(4);
            this.panel_KFC.Name = "panel_KFC";
            this.panel_KFC.Size = new System.Drawing.Size(1759, 754);
            this.panel_KFC.TabIndex = 7;
            // 
            // panel_MC
            // 
            this.panel_MC.Controls.Add(this.button_backToMainMC);
            this.panel_MC.Controls.Add(this.button_AddMC);
            this.panel_MC.Controls.Add(this.button_StergeMC);
            this.panel_MC.Controls.Add(this.button_PlaseazaMC);
            this.panel_MC.Controls.Add(this.label13);
            this.panel_MC.Controls.Add(this.richTextBox_MC);
            this.panel_MC.Controls.Add(this.label14);
            this.panel_MC.Controls.Add(this.comboBox_MC);
            this.panel_MC.Controls.Add(this.label15);
            this.panel_MC.Location = new System.Drawing.Point(25, 5);
            this.panel_MC.Margin = new System.Windows.Forms.Padding(4);
            this.panel_MC.Name = "panel_MC";
            this.panel_MC.Size = new System.Drawing.Size(1770, 754);
            this.panel_MC.TabIndex = 10;
            // 
            // panel_MM
            // 
            this.panel_MM.Controls.Add(this.button_backToMainMM);
            this.panel_MM.Controls.Add(this.button_AddMM);
            this.panel_MM.Controls.Add(this.button_StergeMM);
            this.panel_MM.Controls.Add(this.button_PlaseazaMM);
            this.panel_MM.Controls.Add(this.label16);
            this.panel_MM.Controls.Add(this.richTextBox_MM);
            this.panel_MM.Controls.Add(this.label17);
            this.panel_MM.Controls.Add(this.comboBox_MM);
            this.panel_MM.Controls.Add(this.label18);
            this.panel_MM.Location = new System.Drawing.Point(25, 5);
            this.panel_MM.Margin = new System.Windows.Forms.Padding(4);
            this.panel_MM.Name = "panel_MM";
            this.panel_MM.Size = new System.Drawing.Size(1775, 762);
            this.panel_MM.TabIndex = 11;
            // 
            // panel_TB
            // 
            this.panel_TB.Controls.Add(this.button_backToMainTB);
            this.panel_TB.Controls.Add(this.button_AddTB);
            this.panel_TB.Controls.Add(this.button_StergeTB);
            this.panel_TB.Controls.Add(this.button_PlaseazaTB);
            this.panel_TB.Controls.Add(this.label10);
            this.panel_TB.Controls.Add(this.richTextBox_TB);
            this.panel_TB.Controls.Add(this.label11);
            this.panel_TB.Controls.Add(this.comboBox_TB);
            this.panel_TB.Controls.Add(this.label12);
            this.panel_TB.Location = new System.Drawing.Point(24, 5);
            this.panel_TB.Margin = new System.Windows.Forms.Padding(4);
            this.panel_TB.Name = "panel_TB";
            this.panel_TB.Size = new System.Drawing.Size(1775, 762);
            this.panel_TB.TabIndex = 9;
            // 
            // button_backToMainTB
            // 
            this.button_backToMainTB.Font = new System.Drawing.Font("Algerian", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_backToMainTB.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button_backToMainTB.Location = new System.Drawing.Point(697, 585);
            this.button_backToMainTB.Margin = new System.Windows.Forms.Padding(4);
            this.button_backToMainTB.Name = "button_backToMainTB";
            this.button_backToMainTB.Size = new System.Drawing.Size(311, 121);
            this.button_backToMainTB.TabIndex = 8;
            this.button_backToMainTB.Text = "Inapoi la pagina principala";
            this.button_backToMainTB.UseVisualStyleBackColor = true;
            this.button_backToMainTB.Click += new System.EventHandler(this.button_backToMainTB_Click);
            // 
            // button_AddTB
            // 
            this.button_AddTB.Font = new System.Drawing.Font("Algerian", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_AddTB.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button_AddTB.Location = new System.Drawing.Point(697, 170);
            this.button_AddTB.Margin = new System.Windows.Forms.Padding(4);
            this.button_AddTB.Name = "button_AddTB";
            this.button_AddTB.Size = new System.Drawing.Size(311, 121);
            this.button_AddTB.TabIndex = 7;
            this.button_AddTB.Text = "Adauga Produs";
            this.button_AddTB.UseVisualStyleBackColor = true;
            this.button_AddTB.Click += new System.EventHandler(this.button_AddTB_Click);
            // 
            // button_StergeTB
            // 
            this.button_StergeTB.Font = new System.Drawing.Font("Algerian", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_StergeTB.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button_StergeTB.Location = new System.Drawing.Point(1067, 585);
            this.button_StergeTB.Margin = new System.Windows.Forms.Padding(4);
            this.button_StergeTB.Name = "button_StergeTB";
            this.button_StergeTB.Size = new System.Drawing.Size(311, 121);
            this.button_StergeTB.TabIndex = 6;
            this.button_StergeTB.Text = "Sterge Comanda";
            this.button_StergeTB.UseVisualStyleBackColor = true;
            this.button_StergeTB.Click += new System.EventHandler(this.button_StergeTB_Click);
            // 
            // button_PlaseazaTB
            // 
            this.button_PlaseazaTB.Font = new System.Drawing.Font("Algerian", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_PlaseazaTB.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button_PlaseazaTB.Location = new System.Drawing.Point(1428, 585);
            this.button_PlaseazaTB.Margin = new System.Windows.Forms.Padding(4);
            this.button_PlaseazaTB.Name = "button_PlaseazaTB";
            this.button_PlaseazaTB.Size = new System.Drawing.Size(311, 121);
            this.button_PlaseazaTB.TabIndex = 5;
            this.button_PlaseazaTB.Text = "Plaseaza Comanda";
            this.button_PlaseazaTB.UseVisualStyleBackColor = true;
            this.button_PlaseazaTB.Click += new System.EventHandler(this.button_PlaseazaTB_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Algerian", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.White;
            this.label10.Location = new System.Drawing.Point(1275, 107);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(292, 30);
            this.label10.TabIndex = 4;
            this.label10.Text = "Produse Comandate";
            // 
            // richTextBox_TB
            // 
            this.richTextBox_TB.Location = new System.Drawing.Point(1067, 167);
            this.richTextBox_TB.Margin = new System.Windows.Forms.Padding(4);
            this.richTextBox_TB.Name = "richTextBox_TB";
            this.richTextBox_TB.Size = new System.Drawing.Size(672, 371);
            this.richTextBox_TB.TabIndex = 3;
            this.richTextBox_TB.Text = "";
            this.richTextBox_TB.TextChanged += new System.EventHandler(this.richTextBox_TB_TextChanged);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Algerian", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.White;
            this.label11.Location = new System.Drawing.Point(239, 107);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(231, 30);
            this.label11.TabIndex = 2;
            this.label11.Text = "Alege din meniu";
            // 
            // comboBox_TB
            // 
            this.comboBox_TB.FormattingEnabled = true;
            this.comboBox_TB.Location = new System.Drawing.Point(59, 174);
            this.comboBox_TB.Margin = new System.Windows.Forms.Padding(4);
            this.comboBox_TB.Name = "comboBox_TB";
            this.comboBox_TB.Size = new System.Drawing.Size(595, 24);
            this.comboBox_TB.TabIndex = 1;
            this.comboBox_TB.SelectedIndexChanged += new System.EventHandler(this.comboBox_TB_SelectedIndexChanged);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Algerian", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.White;
            this.label12.Location = new System.Drawing.Point(636, 39);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(535, 38);
            this.label12.TabIndex = 0;
            this.label12.Text = "Bine ati venit la Taco Bell!";
            // 
            // button_backToMainMM
            // 
            this.button_backToMainMM.Font = new System.Drawing.Font("Algerian", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_backToMainMM.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button_backToMainMM.Location = new System.Drawing.Point(697, 585);
            this.button_backToMainMM.Margin = new System.Windows.Forms.Padding(4);
            this.button_backToMainMM.Name = "button_backToMainMM";
            this.button_backToMainMM.Size = new System.Drawing.Size(311, 121);
            this.button_backToMainMM.TabIndex = 8;
            this.button_backToMainMM.Text = "Inapoi la pagina principala";
            this.button_backToMainMM.UseVisualStyleBackColor = true;
            this.button_backToMainMM.Click += new System.EventHandler(this.button_backToMainMM_Click);
            // 
            // button_AddMM
            // 
            this.button_AddMM.Font = new System.Drawing.Font("Algerian", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_AddMM.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button_AddMM.Location = new System.Drawing.Point(697, 170);
            this.button_AddMM.Margin = new System.Windows.Forms.Padding(4);
            this.button_AddMM.Name = "button_AddMM";
            this.button_AddMM.Size = new System.Drawing.Size(311, 121);
            this.button_AddMM.TabIndex = 7;
            this.button_AddMM.Text = "Adauga Produs";
            this.button_AddMM.UseVisualStyleBackColor = true;
            this.button_AddMM.Click += new System.EventHandler(this.button_AddMM_Click);
            // 
            // button_StergeMM
            // 
            this.button_StergeMM.Font = new System.Drawing.Font("Algerian", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_StergeMM.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button_StergeMM.Location = new System.Drawing.Point(1067, 585);
            this.button_StergeMM.Margin = new System.Windows.Forms.Padding(4);
            this.button_StergeMM.Name = "button_StergeMM";
            this.button_StergeMM.Size = new System.Drawing.Size(311, 121);
            this.button_StergeMM.TabIndex = 6;
            this.button_StergeMM.Text = "Sterge Comanda";
            this.button_StergeMM.UseVisualStyleBackColor = true;
            this.button_StergeMM.Click += new System.EventHandler(this.button_StergeMM_Click);
            // 
            // button_PlaseazaMM
            // 
            this.button_PlaseazaMM.Font = new System.Drawing.Font("Algerian", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_PlaseazaMM.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button_PlaseazaMM.Location = new System.Drawing.Point(1428, 585);
            this.button_PlaseazaMM.Margin = new System.Windows.Forms.Padding(4);
            this.button_PlaseazaMM.Name = "button_PlaseazaMM";
            this.button_PlaseazaMM.Size = new System.Drawing.Size(311, 121);
            this.button_PlaseazaMM.TabIndex = 5;
            this.button_PlaseazaMM.Text = "Plaseaza Comanda";
            this.button_PlaseazaMM.UseVisualStyleBackColor = true;
            this.button_PlaseazaMM.Click += new System.EventHandler(this.button_PlaseazaMM_Click);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Algerian", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.White;
            this.label16.Location = new System.Drawing.Point(1275, 107);
            this.label16.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(292, 30);
            this.label16.TabIndex = 4;
            this.label16.Text = "Produse Comandate";
            // 
            // richTextBox_MM
            // 
            this.richTextBox_MM.Location = new System.Drawing.Point(1067, 167);
            this.richTextBox_MM.Margin = new System.Windows.Forms.Padding(4);
            this.richTextBox_MM.Name = "richTextBox_MM";
            this.richTextBox_MM.Size = new System.Drawing.Size(672, 371);
            this.richTextBox_MM.TabIndex = 3;
            this.richTextBox_MM.Text = "";
            this.richTextBox_MM.TextChanged += new System.EventHandler(this.richTextBox_MM_TextChanged);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Algerian", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.Color.White;
            this.label17.Location = new System.Drawing.Point(239, 107);
            this.label17.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(231, 30);
            this.label17.TabIndex = 2;
            this.label17.Text = "Alege din meniu";
            // 
            // comboBox_MM
            // 
            this.comboBox_MM.FormattingEnabled = true;
            this.comboBox_MM.Location = new System.Drawing.Point(59, 174);
            this.comboBox_MM.Margin = new System.Windows.Forms.Padding(4);
            this.comboBox_MM.Name = "comboBox_MM";
            this.comboBox_MM.Size = new System.Drawing.Size(595, 24);
            this.comboBox_MM.TabIndex = 1;
            this.comboBox_MM.SelectedIndexChanged += new System.EventHandler(this.comboBox_MM_SelectedIndexChanged);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Algerian", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.Color.White;
            this.label18.Location = new System.Drawing.Point(636, 39);
            this.label18.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(555, 38);
            this.label18.TabIndex = 0;
            this.label18.Text = "Bine ati venit la Mamma Mia!";
            // 
            // button_backToMainMC
            // 
            this.button_backToMainMC.Font = new System.Drawing.Font("Algerian", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_backToMainMC.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button_backToMainMC.Location = new System.Drawing.Point(697, 585);
            this.button_backToMainMC.Margin = new System.Windows.Forms.Padding(4);
            this.button_backToMainMC.Name = "button_backToMainMC";
            this.button_backToMainMC.Size = new System.Drawing.Size(311, 121);
            this.button_backToMainMC.TabIndex = 8;
            this.button_backToMainMC.Text = "Inapoi la pagina principala";
            this.button_backToMainMC.UseVisualStyleBackColor = true;
            this.button_backToMainMC.Click += new System.EventHandler(this.button_backToMainMC_Click);
            // 
            // button_AddMC
            // 
            this.button_AddMC.Font = new System.Drawing.Font("Algerian", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_AddMC.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button_AddMC.Location = new System.Drawing.Point(697, 170);
            this.button_AddMC.Margin = new System.Windows.Forms.Padding(4);
            this.button_AddMC.Name = "button_AddMC";
            this.button_AddMC.Size = new System.Drawing.Size(311, 121);
            this.button_AddMC.TabIndex = 7;
            this.button_AddMC.Text = "Adauga Produs";
            this.button_AddMC.UseVisualStyleBackColor = true;
            this.button_AddMC.Click += new System.EventHandler(this.button_AddMC_Click);
            // 
            // button_StergeMC
            // 
            this.button_StergeMC.Font = new System.Drawing.Font("Algerian", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_StergeMC.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button_StergeMC.Location = new System.Drawing.Point(1067, 585);
            this.button_StergeMC.Margin = new System.Windows.Forms.Padding(4);
            this.button_StergeMC.Name = "button_StergeMC";
            this.button_StergeMC.Size = new System.Drawing.Size(311, 121);
            this.button_StergeMC.TabIndex = 6;
            this.button_StergeMC.Text = "Sterge Comanda";
            this.button_StergeMC.UseVisualStyleBackColor = true;
            this.button_StergeMC.Click += new System.EventHandler(this.button_StergeMC_Click);
            // 
            // button_PlaseazaMC
            // 
            this.button_PlaseazaMC.Font = new System.Drawing.Font("Algerian", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_PlaseazaMC.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button_PlaseazaMC.Location = new System.Drawing.Point(1428, 585);
            this.button_PlaseazaMC.Margin = new System.Windows.Forms.Padding(4);
            this.button_PlaseazaMC.Name = "button_PlaseazaMC";
            this.button_PlaseazaMC.Size = new System.Drawing.Size(311, 121);
            this.button_PlaseazaMC.TabIndex = 5;
            this.button_PlaseazaMC.Text = "Plaseaza Comanda";
            this.button_PlaseazaMC.UseVisualStyleBackColor = true;
            this.button_PlaseazaMC.Click += new System.EventHandler(this.button_PlaseazaMC_Click);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Algerian", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.White;
            this.label13.Location = new System.Drawing.Point(1275, 107);
            this.label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(292, 30);
            this.label13.TabIndex = 4;
            this.label13.Text = "Produse Comandate";
            // 
            // richTextBox_MC
            // 
            this.richTextBox_MC.Location = new System.Drawing.Point(1067, 167);
            this.richTextBox_MC.Margin = new System.Windows.Forms.Padding(4);
            this.richTextBox_MC.Name = "richTextBox_MC";
            this.richTextBox_MC.Size = new System.Drawing.Size(672, 371);
            this.richTextBox_MC.TabIndex = 3;
            this.richTextBox_MC.Text = "";
            this.richTextBox_MC.TextChanged += new System.EventHandler(this.richTextBox_MC_TextChanged);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Algerian", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.White;
            this.label14.Location = new System.Drawing.Point(239, 107);
            this.label14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(231, 30);
            this.label14.TabIndex = 2;
            this.label14.Text = "Alege din meniu";
            // 
            // comboBox_MC
            // 
            this.comboBox_MC.FormattingEnabled = true;
            this.comboBox_MC.Location = new System.Drawing.Point(59, 174);
            this.comboBox_MC.Margin = new System.Windows.Forms.Padding(4);
            this.comboBox_MC.Name = "comboBox_MC";
            this.comboBox_MC.Size = new System.Drawing.Size(595, 24);
            this.comboBox_MC.TabIndex = 1;
            this.comboBox_MC.SelectedIndexChanged += new System.EventHandler(this.comboBox_MC_SelectedIndexChanged);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Algerian", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.White;
            this.label15.Location = new System.Drawing.Point(636, 39);
            this.label15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(558, 38);
            this.label15.TabIndex = 0;
            this.label15.Text = "Bine ati venit la McDonald\'s!";
            // 
            // button_backToMain
            // 
            this.button_backToMain.Font = new System.Drawing.Font("Algerian", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_backToMain.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button_backToMain.Location = new System.Drawing.Point(697, 585);
            this.button_backToMain.Margin = new System.Windows.Forms.Padding(4);
            this.button_backToMain.Name = "button_backToMain";
            this.button_backToMain.Size = new System.Drawing.Size(311, 121);
            this.button_backToMain.TabIndex = 8;
            this.button_backToMain.Text = "Inapoi la pagina principala";
            this.button_backToMain.UseVisualStyleBackColor = true;
            this.button_backToMain.Click += new System.EventHandler(this.button_backToMain_Click);
            // 
            // button_AddKfc
            // 
            this.button_AddKfc.Font = new System.Drawing.Font("Algerian", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_AddKfc.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button_AddKfc.Location = new System.Drawing.Point(697, 170);
            this.button_AddKfc.Margin = new System.Windows.Forms.Padding(4);
            this.button_AddKfc.Name = "button_AddKfc";
            this.button_AddKfc.Size = new System.Drawing.Size(311, 121);
            this.button_AddKfc.TabIndex = 7;
            this.button_AddKfc.Text = "Adauga Produs";
            this.button_AddKfc.UseVisualStyleBackColor = true;
            this.button_AddKfc.Click += new System.EventHandler(this.button_AddKfc_Click);
            // 
            // button_StergeKFC
            // 
            this.button_StergeKFC.Font = new System.Drawing.Font("Algerian", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_StergeKFC.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button_StergeKFC.Location = new System.Drawing.Point(1067, 585);
            this.button_StergeKFC.Margin = new System.Windows.Forms.Padding(4);
            this.button_StergeKFC.Name = "button_StergeKFC";
            this.button_StergeKFC.Size = new System.Drawing.Size(311, 121);
            this.button_StergeKFC.TabIndex = 6;
            this.button_StergeKFC.Text = "Sterge Comanda";
            this.button_StergeKFC.UseVisualStyleBackColor = true;
            this.button_StergeKFC.Click += new System.EventHandler(this.button_StergeKFC_Click);
            // 
            // button_PlaseazaKfc
            // 
            this.button_PlaseazaKfc.Font = new System.Drawing.Font("Algerian", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_PlaseazaKfc.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button_PlaseazaKfc.Location = new System.Drawing.Point(1428, 585);
            this.button_PlaseazaKfc.Margin = new System.Windows.Forms.Padding(4);
            this.button_PlaseazaKfc.Name = "button_PlaseazaKfc";
            this.button_PlaseazaKfc.Size = new System.Drawing.Size(311, 121);
            this.button_PlaseazaKfc.TabIndex = 5;
            this.button_PlaseazaKfc.Text = "Plaseaza Comanda";
            this.button_PlaseazaKfc.UseVisualStyleBackColor = true;
            this.button_PlaseazaKfc.Click += new System.EventHandler(this.button_PlaseazaKfc_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Algerian", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(1275, 107);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(292, 30);
            this.label9.TabIndex = 4;
            this.label9.Text = "Produse Comandate";
            // 
            // richTextBox_KFC
            // 
            this.richTextBox_KFC.Location = new System.Drawing.Point(1067, 167);
            this.richTextBox_KFC.Margin = new System.Windows.Forms.Padding(4);
            this.richTextBox_KFC.Name = "richTextBox_KFC";
            this.richTextBox_KFC.Size = new System.Drawing.Size(672, 371);
            this.richTextBox_KFC.TabIndex = 3;
            this.richTextBox_KFC.Text = "";
            this.richTextBox_KFC.TextChanged += new System.EventHandler(this.richTextBox_KFC_TextChanged);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Algerian", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(239, 107);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(231, 30);
            this.label8.TabIndex = 2;
            this.label8.Text = "Alege din meniu";
            // 
            // comboBox_KFC
            // 
            this.comboBox_KFC.FormattingEnabled = true;
            this.comboBox_KFC.Location = new System.Drawing.Point(59, 174);
            this.comboBox_KFC.Margin = new System.Windows.Forms.Padding(4);
            this.comboBox_KFC.Name = "comboBox_KFC";
            this.comboBox_KFC.Size = new System.Drawing.Size(595, 24);
            this.comboBox_KFC.TabIndex = 1;
            this.comboBox_KFC.SelectedIndexChanged += new System.EventHandler(this.comboBox_KFC_SelectedIndexChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Algerian", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(636, 39);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(414, 38);
            this.label5.TabIndex = 0;
            this.label5.Text = "Bine ati venit la KFC!";
            // 
            // button_MM
            // 
            this.button_MM.Location = new System.Drawing.Point(1327, 298);
            this.button_MM.Margin = new System.Windows.Forms.Padding(4);
            this.button_MM.Name = "button_MM";
            this.button_MM.Size = new System.Drawing.Size(133, 62);
            this.button_MM.TabIndex = 2;
            this.button_MM.Text = "Mamma Mia";
            this.button_MM.UseVisualStyleBackColor = true;
            this.button_MM.Click += new System.EventHandler(this.button_MM_Click);
            // 
            // button_MC
            // 
            this.button_MC.Location = new System.Drawing.Point(169, 663);
            this.button_MC.Margin = new System.Windows.Forms.Padding(4);
            this.button_MC.Name = "button_MC";
            this.button_MC.Size = new System.Drawing.Size(133, 62);
            this.button_MC.TabIndex = 3;
            this.button_MC.Text = "McDonald\'s";
            this.button_MC.UseVisualStyleBackColor = true;
            this.button_MC.Click += new System.EventHandler(this.button_MC_Click);
            // 
            // button_TB
            // 
            this.button_TB.Location = new System.Drawing.Point(1327, 663);
            this.button_TB.Margin = new System.Windows.Forms.Padding(4);
            this.button_TB.Name = "button_TB";
            this.button_TB.Size = new System.Drawing.Size(133, 62);
            this.button_TB.TabIndex = 4;
            this.button_TB.Text = "Taco Bell";
            this.button_TB.UseVisualStyleBackColor = true;
            this.button_TB.Click += new System.EventHandler(this.button_TB_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.ErrorImage = null;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.InitialImage = null;
            this.pictureBox1.Location = new System.Drawing.Point(45, 52);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(551, 239);
            this.pictureBox1.TabIndex = 5;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.ErrorImage = null;
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.InitialImage = null;
            this.pictureBox2.Location = new System.Drawing.Point(1100, 417);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(551, 239);
            this.pictureBox2.TabIndex = 6;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.ErrorImage = null;
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.InitialImage = null;
            this.pictureBox3.Location = new System.Drawing.Point(45, 417);
            this.pictureBox3.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(551, 239);
            this.pictureBox3.TabIndex = 7;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.ErrorImage = null;
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.InitialImage = null;
            this.pictureBox4.Location = new System.Drawing.Point(1100, 52);
            this.pictureBox4.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(551, 239);
            this.pictureBox4.TabIndex = 8;
            this.pictureBox4.TabStop = false;
            // 
            // panel_Main
            // 
            this.panel_Main.Controls.Add(this.pictureBox4);
            this.panel_Main.Controls.Add(this.pictureBox3);
            this.panel_Main.Controls.Add(this.pictureBox2);
            this.panel_Main.Controls.Add(this.pictureBox1);
            this.panel_Main.Controls.Add(this.button_TB);
            this.panel_Main.Controls.Add(this.button_MC);
            this.panel_Main.Controls.Add(this.button_MM);
            this.panel_Main.Controls.Add(this.button_KFC);
            this.panel_Main.Controls.Add(this.label7);
            this.panel_Main.Location = new System.Drawing.Point(24, 30);
            this.panel_Main.Margin = new System.Windows.Forms.Padding(4);
            this.panel_Main.Name = "panel_Main";
            this.panel_Main.Size = new System.Drawing.Size(1761, 737);
            this.panel_Main.TabIndex = 9;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DodgerBlue;
            this.ClientSize = new System.Drawing.Size(1823, 782);
            this.Controls.Add(this.panel_MM);
            this.Controls.Add(this.panel_TB);
            this.Controls.Add(this.panel_KFC);
            this.Controls.Add(this.panel_MC);
            this.Controls.Add(this.panel_Main);
            this.Controls.Add(this.panel_Login);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.Text = "Restaurant ";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel_Login.ResumeLayout(false);
            this.panel_Login.PerformLayout();
            this.panel_KFC.ResumeLayout(false);
            this.panel_KFC.PerformLayout();
            this.panel_MC.ResumeLayout(false);
            this.panel_MC.PerformLayout();
            this.panel_MM.ResumeLayout(false);
            this.panel_MM.PerformLayout();
            this.panel_TB.ResumeLayout(false);
            this.panel_TB.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.panel_Main.ResumeLayout(false);
            this.panel_Main.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox Parola_Box;
        private System.Windows.Forms.TextBox Username_Box;
        private System.Windows.Forms.Button button_Exit;
        private System.Windows.Forms.Button button_Help;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel panel_Login;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button button_KFC;
        private System.Windows.Forms.Panel panel_KFC;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button button_TB;
        private System.Windows.Forms.Button button_MC;
        private System.Windows.Forms.Button button_MM;
        private System.Windows.Forms.Panel panel_TB;
        private System.Windows.Forms.Panel panel_MC;
        private System.Windows.Forms.Panel panel_MM;
        private System.Windows.Forms.Button button_backToMainMM;
        private System.Windows.Forms.Button button_AddMM;
        private System.Windows.Forms.Button button_StergeMM;
        private System.Windows.Forms.Button button_PlaseazaMM;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.RichTextBox richTextBox_MM;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.ComboBox comboBox_MM;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Button button_backToMainMC;
        private System.Windows.Forms.Button button_AddMC;
        private System.Windows.Forms.Button button_StergeMC;
        private System.Windows.Forms.Button button_PlaseazaMC;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.RichTextBox richTextBox_MC;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.ComboBox comboBox_MC;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Button button_backToMainTB;
        private System.Windows.Forms.Button button_AddTB;
        private System.Windows.Forms.Button button_StergeTB;
        private System.Windows.Forms.Button button_PlaseazaTB;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.RichTextBox richTextBox_TB;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ComboBox comboBox_TB;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button button_backToMain;
        private System.Windows.Forms.Button button_AddKfc;
        private System.Windows.Forms.Button button_StergeKFC;
        private System.Windows.Forms.Button button_PlaseazaKfc;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.RichTextBox richTextBox_KFC;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox comboBox_KFC;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Panel panel_Main;
        private System.Windows.Forms.Button button_Login;
    }
}

