﻿/************************************************************
 *                                                          *
 *   File: Form1.cs                                         *
 *   Copyright: (c) 2021, Moroșanu Radu-George              *
 *   Description: Aplicatie de tip food delivery            *
 *                                                          *
 *                                                          *
 *                                                          *
 *                                                          *
 ************************************************************/

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using ManagerProduse;

namespace Produse
{
    public class ProduseMM : IManagerProduse
    {
        /// <summary>
        /// Clasa care se ocupa de administrarea produselor din restaurantul MammaMia
        /// </summary>
        private List<string> _products;
        private const string resources = "Produse\\";

        /// <summary>
        /// Constructorul clasei ProduseMM care are rolul de a actualiza lista cu produse din fisierul produseMM
        /// </summary>
        public ProduseMM()
        {
            try
            {
                _products = new List<string>();
                StreamReader sr = new StreamReader("E:\\ELISA\\AN III\\SEM II\\IP\\proiect_git\\V4\\Restaurant\\produseMM.txt");
                string line;
                line = sr.ReadLine();
                if (line == null)
                    Console.WriteLine("Fisier gol");
                else
                {
                    while (line != null)
                    {
                        _products.Add(line);
                        line = sr.ReadLine();
                    }
                }
            }
            catch (FileNotFoundException e)
            {
                Console.WriteLine(e);
            }
        }

        /// <summary>
        /// Metoda care returneaza numarul de produse din meniul MammaMia
        /// </summary>
        /// <returns>Numarul produselor MammaMia din lista</returns>
        public int GetNrProduse()
        {
            return _products.Count;
        }

        /// <summary>
        /// Metoda care verifica daca se afla produse in lista meniului Mamma Mia
        /// </summary>
        /// <returns>True sau False in functie de numarul de produse din lista</returns>
        public Boolean checkNull(List<string> lista)
        {
            if (lista.Count == 0)
                return true;
            else
                return false;
        }

        /// <summary>
        ///Metoda care returneaza lista cu numele produselor din meniul restaurantului MammaMia
        /// </summary>
        /// <returns>Lista cu numele produselor din meniul restaurantului MammaMia</returns>
        public string[] ReturnAll()
        {
            string[] lista_produse = new string[_products.Count];
            if (checkNull(_products) == true)
                return null;
            for (int i = 0; i < _products.Count; i++)
                lista_produse[i] = _products[i];

            return lista_produse;


        }
    }
}

