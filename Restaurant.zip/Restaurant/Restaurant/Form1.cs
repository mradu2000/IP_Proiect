﻿/************************************************************
 *                                                          *
 *   File: Form1.cs                                         *
 *   Copyright: (c) 2021, Jardă Maria-Elisabeta             *
 *   Description: Aplicatie de tip food delivery            *
 *                                                          *
 *                                                          *
 *                                                          *
 *                                                          *
 ************************************************************/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using ProxyUser;
using ManagerProduse;
using Produse;

namespace Restaurant
{
    public partial class Form1 : Form
    {
        /// <summary>
        /// Clasa care implementeaza Form si are logica aplicatiei grafice
        /// </summary>
        List<Panel> listPanel = new List<Panel>();
        private string _username;
        private string _password;
        private IManagerProduse _managerKFC;
        private IManagerProduse _managerMM;
        private IManagerProduse _managerMC;
        private IManagerProduse _managerTB;
        Proxy _user;

        Queue<string> coadaComenzi = new Queue<string>();
        private string _usernameClient;

        /// <summary>
        /// Constructorul clasei
        /// </summary>
        public Form1()
        {
            InitializeComponent();

            _managerKFC = new ProduseKFC();
            _managerMM = new ProduseMM();
            _managerMC = new ProduseMC();
            _managerTB = new ProduseTB();

            _user = new Proxy();
        }

        /// <summary>
        /// Functionalitatea butonului de inregistrare in aplicatie
        /// </summary>
        /// <param name="sender">Referinta catre eveniment</param>
        /// <param name="e">Instanta unui eveniment</param>
        private void button_Login_Click(object sender, EventArgs e)
        {
            _username = Username_Box.Text;
            _password = Parola_Box.Text;
            bool ok = _user.Inregistrare(_username, _password);
            if (!ok)
            {
                MessageBox.Show("Eroare! Utilizator sau parola incorecte! ");
                return;
            }

            if (_username.Equals("curier"))
            {
                listPanel[6].BringToFront();
            }
            else
            {
                listPanel[1].BringToFront();
                _usernameClient = _username;
            }

        }

        /// <summary>
        /// Metoda care incarca interfata grafica
        /// </summary>
        /// <param name="sender">Referinta catre eveniment</param>
        /// <param name="e">Instanta unui eveniment</param>
        private void Form1_Load(object sender, EventArgs e)
        {
            listPanel.Add(panel_Login);
            listPanel.Add(panel_Main);
            listPanel.Add(panel_MC);
            listPanel.Add(panel_MM);
            listPanel.Add(panel_TB);
            listPanel.Add(panel_KFC);
            listPanel.Add(panel_OS);
            listPanel[0].BringToFront();
            ComboBoxKFC();
            ComboBoxMC();
            ComboBoxMM();
            ComboBoxTB();
        }


        /// <summary>
        /// Metoda care deschide o fereastra ajutatoare (HELP) pentru utilizatorul aplicatie
        /// </summary>
        /// <param name="sender">Referinta catre eveniment</param>
        /// <param name="e">Instanta unui eveniment</param>
        private void button_Help_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("Restaurant.chm");
        }

        /// <summary>
        /// Metoda care inchide aplicatia
        /// </summary>
        /// <param name="sender">Referinta catre eveniment</param>
        /// <param name="e">Instanta unui eveniment</param>
        private void button_Exit_Click(object sender, EventArgs e)
        {
            Close();
        }

        // Main Panel si butoane

        /// <summary>
        /// Metoda care deschide panel-ul pentru Fast-Food-ul KFC
        /// </summary>
        /// <param name="sender">Referinta catre eveniment</param>
        /// <param name="e">Instanta unui eveniment</param>
        private void button_KFC_Click(object sender, EventArgs e)
        {
            listPanel[5].BringToFront();       
        }

        /// <summary>
        /// Metoda care deschide panel-ul pentru restaurantul MammaMia
        /// </summary>
        /// <param name="sender">Referinta catre eveniment</param>
        /// <param name="e">Instanta unui eveniment</param>
        private void button_MM_Click(object sender, EventArgs e)
        {
            listPanel[3].BringToFront();
        }

        /// <summary>
        /// Metoda care deschide panel-ul pentru Fast-Food-ul McDonald's
        /// </summary>
        /// <param name="sender">Referinta catre eveniment</param>
        /// <param name="e">Instanta unui eveniment</param>
        private void button_MC_Click(object sender, EventArgs e)
        {
            listPanel[2].BringToFront();
        }

        /// <summary>
        /// Metoda care deschide panel-ul pentru Fast-Food-ul Taco Bell
        /// </summary>
        /// <param name="sender">Referinta catre eveniment</param>
        /// <param name="e">Instanta unui eveniment</param>
        private void button_TB_Click(object sender, EventArgs e)
        {
            listPanel[4].BringToFront();
        }

        // KFC Panel si butoane

        /// <summary>
        /// Metoda care afiseaza lista cu produsele meniului KFC in interfata
        /// </summary>
        private void ComboBoxKFC()
        {
            try
            {
                string[] produse = _managerKFC.ReturnAll();
                comboBox_KFC.Items.Clear();
                for (int i = 0; i < _managerKFC.GetNrProduse(); ++i)
                {
                    comboBox_KFC.Items.Add(produse[i]);
                }
                comboBox_KFC.SelectedIndex = 0;
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
            }
        }

        /// <summary>
        /// Metoda care populeaza cosul de cumparaturi cu produsele selectate din meniul KFC
        /// </summary>
        /// <param name="sender">Referinta catre eveniment</param>
        /// <param name="e">Instanta unui eveniment</param>
        private void button_AddKfc_Click(object sender, EventArgs e)
        {
            string produs = (String)(comboBox_KFC.SelectedItem);
            richTextBox_KFC.AppendText(String.Format(produs + System.Environment.NewLine));

            coadaComenzi.Enqueue(produs);

        }

        /// <summary>
        /// Metoda prin care se paraseste contul si se ajunge pe pagina de inregistrare
        /// </summary>
        /// <param name="sender">Referinta catre eveniment</param>
        /// <param name="e">Instanta unui eveniment</param>
        private void button_backToMain_Click(object sender, EventArgs e)
        {
            Parola_Box.Text = "";
            Username_Box.Text = "";

            if (richTextBox_KFC.Text.Equals(""))
            {
                listPanel[0].BringToFront();

            }
            else
            {
                MessageBox.Show("Atentie, aveti produse in cos !");
                return;
            }
        }

        /// <summary>
        /// Metoda care goleste cosul de cumparaturi KFC
        /// </summary>
        /// <param name="sender">Referinta catre eveniment</param>
        /// <param name="e">Instanta unui eveniment</param>
        private void button_StergeKFC_Click(object sender, EventArgs e)
        {
            richTextBox_KFC.Text = "";
            coadaComenzi.Clear();
        }

        /// <summary>
        /// Metoda care plaseaza comanda  din cosul de cumparaturi KFC
        /// </summary>
        /// <param name="sender">Referinta catre eveniment</param>
        /// <param name="e">Instanta unui eveniment</param>
        private void button_PlaseazaKfc_Click(object sender, EventArgs e)
        {
            if (richTextBox_KFC.Text.Equals(""))
            {
                MessageBox.Show("Nu aveti produse adaugate in comanda! Va rugam sa adaugati produse!");
            }
            else
            {
                if (_usernameClient != "")
                {
                    coadaComenzi.Enqueue(System.Environment.NewLine + "Comanda de la KFC pentru " + _usernameClient + " este: " + System.Environment.NewLine);
                }
                MessageBox.Show("Comanda dumneavoastra a fost inregistrata cu succes! Va multumim!");
                richTextBox_KFC.Text = "";
                //Close();
            }
        }

        // MammaMia Panel si butoane

        /// <summary>
        /// Metoda care afiseaza lista cu produsele meniului MammaMia in interfata
        /// </summary>
        private void ComboBoxMM()
        {
            try
            {
                string[] produse = _managerMM.ReturnAll();
                comboBox_MM.Items.Clear();
                for (int i = 0; i < _managerMM.GetNrProduse(); ++i)
                {
                    comboBox_MM.Items.Add(produse[i]);
                }
                comboBox_MM.SelectedIndex = 0;
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
            }
        }

        /// <summary>
        /// Metoda care populeaza cosul de cumparaturi cu produsele selectate din meniul Mamma Mia
        /// </summary>
        /// <param name="sender">Referinta catre eveniment</param>
        /// <param name="e">Instanta unui eveniment</param>
        private void button_AddMM_Click(object sender, EventArgs e)
        {
            string produs = (String)(comboBox_MM.SelectedItem);
            richTextBox_MM.AppendText(String.Format(produs + System.Environment.NewLine));

            coadaComenzi.Enqueue(produs);
        }


        /// <summary>
        /// Metoda prin care se paraseste contul si se ajunge pe pagina de inregistrare
        /// </summary>
        /// <param name="sender">Referinta catre eveniment</param>
        /// <param name="e">Instanta unui eveniment</param>
        private void button_backToMainMM_Click(object sender, EventArgs e)
        {
            Parola_Box.Text = "";
            Username_Box.Text = "";

            if (richTextBox_MM.Text.Equals(""))
            {
                listPanel[0].BringToFront();

            }
            else
            {
                MessageBox.Show("Atentie, aveti produse in cos !");
                return;
            }
        }

        /// <summary>
        /// Metoda care goleste cosul de cumparaturi MammaMia
        /// </summary>
        /// <param name="sender">Referinta catre eveniment</param>
        /// <param name="e">Instanta unui eveniment</param>
        private void button_StergeMM_Click(object sender, EventArgs e)
        {
            richTextBox_MM.Text = "";
            coadaComenzi.Clear();
        }

        /// <summary>
        /// Metoda care plaseaza comanda  din cosul de cumparaturi Mamma Mia
        /// </summary>
        /// <param name="sender">Referinta catre eveniment</param>
        /// <param name="e">Instanta unui eveniment</param>
        private void button_PlaseazaMM_Click(object sender, EventArgs e)
        {
            if (richTextBox_MM.Text.Equals(""))
            {
                MessageBox.Show("Nu aveti produse adaugate in comanda! Va rugam sa adaugati produse!");
            }
            else
            {
                if (_usernameClient != "")
                {
                    coadaComenzi.Enqueue(System.Environment.NewLine + "Comanda de la MammaMia pentru " + _usernameClient + " este: " + System.Environment.NewLine);
                }
                MessageBox.Show("Comanda dumneavoastra a fost inregistrata cu succes! Va multumim!");
                richTextBox_MM.Text = "";
                //Close();
            }
        }

        // Taco Bell panel si butoane

        /// <summary>
        /// Metoda care afiseaza lista cu produsele meniului Taco Bell in interfata
        /// </summary>
        private void ComboBoxTB()
        {
            try
            {
                string[] produse = _managerTB.ReturnAll();
                comboBox_TB.Items.Clear();
                for (int i = 0; i < _managerTB.GetNrProduse(); ++i)
                {
                    comboBox_TB.Items.Add(produse[i]);
                }
                comboBox_TB.SelectedIndex = 0;
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
            }
        }

        /// <summary>
        /// Metoda care populeaza cosul de cumparaturi cu produsele selectate din meniul Taco Bell
        /// </summary>
        /// <param name="sender">Referinta catre eveniment</param>
        /// <param name="e">Instanta unui eveniment</param>
        private void button_AddTB_Click(object sender, EventArgs e)
        {
            string produs = (String)(comboBox_TB.SelectedItem);
            richTextBox_TB.AppendText(String.Format(produs + System.Environment.NewLine));

            coadaComenzi.Enqueue(produs);
        }


        /// <summary>
        /// Metoda prin care se paraseste contul si se ajunge pe pagina de inregistrare
        /// </summary>
        /// <param name="sender">Referinta catre eveniment</param>
        /// <param name="e">Instanta unui eveniment</param>
        private void button_backToMainTB_Click(object sender, EventArgs e)
        {
            Parola_Box.Text = "";
            Username_Box.Text = "";

            if (richTextBox_TB.Text.Equals(""))
            {
                listPanel[0].BringToFront();

            }
            else
            {
                MessageBox.Show("Atentie, aveti produse in cos !");
                return;
            }
        }

        /// <summary>
        /// Metoda care goleste cosul de cumparaturi Taco Bell
        /// </summary>
        /// <param name="sender">Referinta catre eveniment</param>
        /// <param name="e">Instanta unui eveniment</param>
        private void button_StergeTB_Click(object sender, EventArgs e)
        {
            richTextBox_TB.Text = "";
            coadaComenzi.Clear();
        }

        /// <summary>
        /// Metoda care plaseaza comanda  din cosul de cumparaturi Taco Bell
        /// </summary>
        /// <param name="sender">Referinta catre eveniment</param>
        /// <param name="e">Instanta unui eveniment</param>
        private void button_PlaseazaTB_Click(object sender, EventArgs e)
        {
            if (richTextBox_TB.Text.Equals(""))
            {
                MessageBox.Show("Nu aveti produse adaugate in comanda! Va rugam sa adaugati produse!");
            }
            else
            {
                if (_usernameClient != "")
                {
                    coadaComenzi.Enqueue(System.Environment.NewLine + "Comanda de la Taco Bell pentru " + _usernameClient + " este: " + System.Environment.NewLine);
                }
                MessageBox.Show("Comanda dumneavoastra a fost inregistrata cu succes! Va multumim!");
                richTextBox_TB.Text = "";
                //Close();
            }
        }

        // McDonald's si butoane

        /// <summary>
        /// Metoda care afiseaza lista cu produsele meniului McDonald's in interfata
        /// </summary>
        private void ComboBoxMC()
        {
            try
            {
                string[] produse = _managerMC.ReturnAll();
                comboBox_MC.Items.Clear();
                for (int i = 0; i < _managerMC.GetNrProduse(); ++i)
                {
                    comboBox_MC.Items.Add(produse[i]);
                }
                comboBox_MC.SelectedIndex = 0;
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
            }
        }


        /// <summary>
        /// Metoda care populeaza cosul de cumparaturi cu produsele selectate din meniul McDonald's
        /// </summary>
        /// <param name="sender">Referinta catre eveniment</param>
        /// <param name="e">Instanta unui eveniment</param>
        private void button_AddMC_Click(object sender, EventArgs e)
        {
            string produs = (String)(comboBox_MC.SelectedItem);
            richTextBox_MC.AppendText(String.Format(produs + System.Environment.NewLine));

            coadaComenzi.Enqueue(produs);
        }


        /// <summary>
        /// Metoda prin care se paraseste contul si se ajunge pe pagina de inregistrare
        /// </summary>
        /// <param name="sender">Referinta catre eveniment</param>
        /// <param name="e">Instanta unui eveniment</param>
        private void button_backToMainMC_Click(object sender, EventArgs e)
        {
            Parola_Box.Text = "";
            Username_Box.Text = "";

            if (richTextBox_MC.Text.Equals(""))
            {
                listPanel[0].BringToFront();

            }
            else
            {
                MessageBox.Show("Atentie, aveti produse in cos !");
                return;
            }
        }

        /// <summary>
        /// Metoda care goleste cosul de cumparaturi McDonald's
        /// </summary>
        /// <param name="sender">Referinta catre eveniment</param>
        /// <param name="e">Instanta unui eveniment</param>
        private void button_StergeMC_Click(object sender, EventArgs e)
        {
            richTextBox_MC.Text = "";
            coadaComenzi.Clear();
        }

        /// <summary>
        /// Metoda care plaseaza comanda  din cosul de cumparaturi McDonald's
        /// </summary>
        /// <param name="sender">Referinta catre eveniment</param>
        /// <param name="e">Instanta unui eveniment</param>
        private void button_PlaseazaMC_Click(object sender, EventArgs e)
        {
            if (richTextBox_MC.Text.Equals(""))
            {
                MessageBox.Show("Nu aveti produse adaugate in comanda! Va rugam sa adaugati produse!");
            }
            else
            {
                if (_usernameClient != "")
                {
                    coadaComenzi.Enqueue(System.Environment.NewLine + "Comanda de la McDonald's pentru " + _usernameClient + " este: " + System.Environment.NewLine);
                }
                MessageBox.Show("Comanda dumneavoastra a fost inregistrata cu succes! Va multumim!");
                richTextBox_MC.Text = "";
                //Close();
            }
        }


        //PANEL CURIER

        /// <summary>
        /// Metoda destinata curierului care preia comada
        /// </summary>
        /// <param name="sender">Referinta catre eveniment</param>
        /// <param name="e">Instanta unui eveniment</param>
        private void button_preluare_Click(object sender, EventArgs e)
        {
            if (richTextBox_OS.Text.Equals(""))
            {
                MessageBox.Show("Nu aveti comenzi de preluat!");
            }
            else
            {
                richTextBox_OS.Text = "";
                coadaComenzi.Clear();
                MessageBox.Show("Îți mulțumim pentru servicii! Zi ușoară! ");
               
                //Close();
            }
        }

        /// <summary>
        /// Metoda prin care se paraseste contul si se ajunge pe pagina de inregistrare
        /// </summary>
        /// <param name="sender">Referinta catre eveniment</param>
        /// <param name="e">Instanta unui eveniment</param>
        private void button_backToMainOS_Click(object sender, EventArgs e)
        {
            listPanel[0].BringToFront();
            Parola_Box.Text = "";
            Username_Box.Text = "";
        }

        /// <summary>
        /// Metoda de afisare a tuturor comenzilor disponibile trimise de catre clienti
        /// </summary>
        /// <param name="sender">Referinta catre eveniment</param>
        /// <param name="e">Instanta unui eveniment</param>
        private void button_afisareOS_Click(object sender, EventArgs e)
        {
            if (coadaComenzi.Count > 0)
            {
                
                string[] array = new string[coadaComenzi.Count];
                coadaComenzi.CopyTo(array, 0);       
                richTextBox_OS.AppendText(String.Format("" + System.Environment.NewLine));
                for (int i = array.Length - 1; i >= 0 ; i--)
                  
                    richTextBox_OS.AppendText(String.Format(array[i] + System.Environment.NewLine));
            }
            else
            {
                MessageBox.Show("În acest moment nu sunt comenzi de afisat! Multumim!");
            }
        }
    }
}
