﻿/************************************************************
 *                                                          *
 *   File: Form1.cs                                         *
 *   Copyright: (c) 2021, Țiganaș Ștefan-Gabriel            *
 *   Description: Aplicatie de tip food delivery            *
 *                                                          *
 *                                                          *
 *                                                          *
 *                                                          *
 ************************************************************/

using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using Produse;

namespace UnitTestProduse
{
    [TestClass]
    public class TestProduse
    {

        [TestMethod]
        public void TestMethodMC1()
        {
            ProduseMC produs = new ProduseMC();
            Assert.AreEqual(18, produs.GetNrProduse());
        }

        [TestMethod]
        public void TestMethodMC2()
        {
            ProduseMC produs = new ProduseMC();
            Assert.AreEqual(15, produs.GetNrProduse() + 1);
        }


        [TestMethod]
        public void TestMethodTB1()
        {
            ProduseTB produs = new ProduseTB();
            Assert.AreEqual(10, produs.GetNrProduse());
        }

        [TestMethod]
        public void TestMethodTB2()
        {
            ProduseTB produs = new ProduseTB();
            Assert.AreEqual(9, produs.GetNrProduse() - 5);
        }

        [TestMethod]
        public void TestMethodKFC1()
        {
            ProduseKFC produs = new ProduseKFC();
            Assert.AreEqual(14, produs.GetNrProduse());
        }


        [TestMethod]
        public void TestMethodKFC2()
        {
            ProduseKFC produs = new ProduseKFC();
            Assert.AreEqual(13, produs.GetNrProduse());
        }

        [TestMethod]
        public void TestMethodMM1()
        {
            ProduseMM produs = new ProduseMM();
            Assert.AreEqual(18, produs.GetNrProduse());
        }

        [TestMethod]
        public void TestMethodMM2()
        {
            ProduseMM produs = new ProduseMM();
            Assert.AreEqual(8, produs.GetNrProduse() + 5);
        }


    }
}
