﻿/************************************************************
 *                                                          *
 *   File: Form1.cs                                         *
 *   Copyright: (c) 2021, Moroșanu Radu-George              *
 *   Description: Aplicatie de tip food delivery            *
 *                                                          *
 *                                                          *
 *                                                          *
 *                                                          *
 ************************************************************/

using System;
using System.Collections.Generic;
using System.IO;
using ManagerProduse;
using System.Linq;

namespace Produse
{
    public class ProduseKFC : IManagerProduse
    {
        /// <summary>
        /// Clasa care se ocupa de administrarea produselor din fast-food-ul KFC
        /// </summary>
        private List<string> _products;
        private const string resources = "Produse\\";

        /// <summary>
        /// Constructorul clasei ProduseKFC care are rolul de a actualiza lista cu produse din fisierul produseKFC
        /// </summary>
        public ProduseKFC()
        {
            try
            {
                _products = new List<string>();
                StreamReader sr = new StreamReader("E:\\ELISA\\AN III\\SEM II\\IP\\proiect_git\\V4\\Restaurant\\produseKFC.txt");
                string line;
                line = sr.ReadLine();
                if (line == null)
                    Console.WriteLine("Fisier gol");
                else
                {
                    while (line != null)
                    {
                        _products.Add(line);
                        line = sr.ReadLine();
                    }
                }
            }
            catch (FileNotFoundException e)
            {
                Console.WriteLine(e.ToString());
            }
        }

        /// <summary>
        /// Metoda care returneaza numarul de produse din meniul KFC
        /// </summary>
        /// <returns>Numarul produselor KFC din lista</returns>
        public int GetNrProduse()
        {
            return _products.Count;
        }

        /// <summary>
        /// Metoda care verifica daca se afla produse in lista meniului KFC
        /// </summary>
        /// <returns>True sau False in functie de numarul de produse din lista</returns>
        public Boolean checkNull(List<string> lista)
        {
            if (lista.Count == 0)
                return true;
            else
                return false;
        }

        /// <summary>
        ///Metoda care returneaza lista cu numele produselor din meniul fast-food-ului KFC
        /// </summary>
        /// <returns>Lista cu numele produselor din meniul fast-food-ului KFC</returns>
        public string[] ReturnAll()
        {
            string[] lista_produse = new string[_products.Count];
            if (checkNull(_products) == true)
                return null;
            for (int i = 0; i < _products.Count; i++)
                lista_produse[i] = _products[i];

            return lista_produse;
        }   
    }
}
