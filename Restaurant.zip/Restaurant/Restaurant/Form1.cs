﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using ProxyUser;
using ManagerProduse;
using Produse;

namespace Restaurant
{
    public partial class Form1 : Form
    {

        List<Panel> listPanel = new List<Panel>();
        private string _username;
        private string _password;
        private IManagerProduse _managerKFC;
        private IManagerProduse _managerMM;
        private IManagerProduse _managerMC;
        private IManagerProduse _managerTB;
        Proxy _user;

        //Stack<string> stivaComenzi = new Stack<string>();
        Queue<string> coadaComenzi = new Queue<string>();
        private string _usernameClient;

        public Form1()
        {
            InitializeComponent();

            _managerKFC = new ProduseKFC();
            _managerMM = new ProduseMM();
            _managerMC = new ProduseMC();
            _managerTB = new ProduseTB();

            _user = new Proxy();
        }

        private void button_Login_Click(object sender, EventArgs e)
        {
            _username = Username_Box.Text;
            _password = Parola_Box.Text;
            bool ok = _user.Login(_username, _password);
            if (!ok)
            {
                MessageBox.Show("Eroare! Utilizator sau parola incorecte! ");
                return;
            }

            //listPanel[1].BringToFront();


            if (_username.Equals("curier"))
            {
                listPanel[6].BringToFront();
            }
            else
            {
                listPanel[1].BringToFront();
                _usernameClient = _username;
            }

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            listPanel.Add(panel_Login);
            listPanel.Add(panel_Main);
            listPanel.Add(panel_MC);
            listPanel.Add(panel_MM);
            listPanel.Add(panel_TB);
            listPanel.Add(panel_KFC);
            listPanel.Add(panel_OS);
            listPanel[0].BringToFront();
            ComboBoxKFC();
            ComboBoxMC();
            ComboBoxMM();
            ComboBoxTB();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }


        private void button_Help_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("Restaurant.chm");
        }

        private void button_Exit_Click(object sender, EventArgs e)
        {
            Close();
        }

        // Main Panel si butoane
        private void button_KFC_Click(object sender, EventArgs e)
        {
            listPanel[5].BringToFront();
            /*if (_usernameClient != "")
            {
                //stivaComenzi.Push("Comanda pentru " + _usernameClient + " este: " + System.Environment.NewLine);
                coadaComenzi.Enqueue(System.Environment.NewLine + "Comanda de la KFC pentru " + _usernameClient + " este: " + System.Environment.NewLine);
            }*/
            
        }

        private void button_MM_Click(object sender, EventArgs e)
        {
            listPanel[3].BringToFront();
        }

        private void button_MC_Click(object sender, EventArgs e)
        {
            listPanel[2].BringToFront();
        }

        private void button_TB_Click(object sender, EventArgs e)
        {
            listPanel[4].BringToFront();
        }

        // KFC Panel si butoane

        private void ComboBoxKFC()
        {
            string[] produse = _managerKFC.ReturnAll();
            comboBox_KFC.Items.Clear();
            for (int i = 0; i < _managerKFC.GetNrProduse(); ++i)
            {
                comboBox_KFC.Items.Add(produse[i]);

            }
            comboBox_KFC.SelectedIndex = 0;
        }
        private void comboBox_KFC_SelectedIndexChanged(object sender, EventArgs e)
        {
          
        }

        private void button_AddKfc_Click(object sender, EventArgs e)
        {
            string produs = (String)(comboBox_KFC.SelectedItem);
            richTextBox_KFC.AppendText(String.Format(produs + System.Environment.NewLine));

            //stivaComenzi.Push(produs);
            coadaComenzi.Enqueue(produs);

        }

        private void button_backToMain_Click(object sender, EventArgs e)
        {
            //listPanel[0].BringToFront();
            Parola_Box.Text = "";
            Username_Box.Text = "";

            if (richTextBox_KFC.Text.Equals(""))
            {
                listPanel[0].BringToFront();

            }
            else
            {
                MessageBox.Show("Atentie, aveti produse in cos !");
                return;
            }
        }

        private void button_StergeKFC_Click(object sender, EventArgs e)
        {
            richTextBox_KFC.Text = "";
            coadaComenzi.Clear();
        }

        private void button_PlaseazaKfc_Click(object sender, EventArgs e)
        {
            if (richTextBox_KFC.Text.Equals(""))
            {
                MessageBox.Show("Nu aveti produse adaugate in comanda! Va rugam sa adaugati produse!");
            }
            else
            {
                //stivaComenzi.Push(richTextBox_KFC.Text);
                if (_usernameClient != "")
                {
                    //stivaComenzi.Push("Comanda pentru " + _usernameClient + " este: " + System.Environment.NewLine);
                    coadaComenzi.Enqueue(System.Environment.NewLine + "Comanda de la KFC pentru " + _usernameClient + " este: " + System.Environment.NewLine);
                }
                MessageBox.Show("Comanda dumneavoastra a fost inregistrata cu succes! Va multumim!");
                richTextBox_KFC.Text = "";
                //Close();
            }
        }

        private void richTextBox_KFC_TextChanged(object sender, EventArgs e)
        {

        }

        // MammaMia Panel si butoane

        private void ComboBoxMM()
        {
            string[] produse = _managerMM.ReturnAll();
            comboBox_MM.Items.Clear();
            for (int i = 0; i < _managerMM.GetNrProduse(); ++i)
            {
                comboBox_MM.Items.Add(produse[i]);

            }
            comboBox_MM.SelectedIndex = 0;
        }
        private void comboBox_MM_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button_AddMM_Click(object sender, EventArgs e)
        {
            string produs = (String)(comboBox_MM.SelectedItem);
            richTextBox_MM.AppendText(String.Format(produs + System.Environment.NewLine));

            coadaComenzi.Enqueue(produs);
        }

        private void richTextBox_MM_TextChanged(object sender, EventArgs e)
        {

        }

        private void button_backToMainMM_Click(object sender, EventArgs e)
        {
            //listPanel[0].BringToFront();
            Parola_Box.Text = "";
            Username_Box.Text = "";

            if (richTextBox_MM.Text.Equals(""))
            {
                listPanel[0].BringToFront();

            }
            else
            {
                MessageBox.Show("Atentie, aveti produse in cos !");
                return;
            }
        }

        private void button_StergeMM_Click(object sender, EventArgs e)
        {
            richTextBox_MM.Text = "";
            coadaComenzi.Clear();
        }

        private void button_PlaseazaMM_Click(object sender, EventArgs e)
        {
            if (richTextBox_MM.Text.Equals(""))
            {
                MessageBox.Show("Nu aveti produse adaugate in comanda! Va rugam sa adaugati produse!");
            }
            else
            {
                if (_usernameClient != "")
                {
                    coadaComenzi.Enqueue(System.Environment.NewLine + "Comanda de la MammaMia pentru " + _usernameClient + " este: " + System.Environment.NewLine);
                }
                MessageBox.Show("Comanda dumneavoastra a fost inregistrata cu succes! Va multumim!");
                richTextBox_MM.Text = "";
                //Close();
            }
        }

        // Taco Bell panel si butoane

        private void ComboBoxTB()
        {
            string[] produse = _managerTB.ReturnAll();
            comboBox_TB.Items.Clear();
            for (int i = 0; i < _managerTB.GetNrProduse(); ++i)
            {
                comboBox_TB.Items.Add(produse[i]);

            }
            comboBox_TB.SelectedIndex = 0;
        }
        private void comboBox_TB_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button_AddTB_Click(object sender, EventArgs e)
        {
            string produs = (String)(comboBox_TB.SelectedItem);
            richTextBox_TB.AppendText(String.Format(produs + System.Environment.NewLine));

            coadaComenzi.Enqueue(produs);
        }

        private void richTextBox_TB_TextChanged(object sender, EventArgs e)
        {

        }

        private void button_backToMainTB_Click(object sender, EventArgs e)
        {
            //listPanel[0].BringToFront();
            Parola_Box.Text = "";
            Username_Box.Text = "";

            if (richTextBox_TB.Text.Equals(""))
            {
                listPanel[0].BringToFront();

            }
            else
            {
                MessageBox.Show("Atentie, aveti produse in cos !");
                return;
            }
        }

        private void button_StergeTB_Click(object sender, EventArgs e)
        {
            richTextBox_TB.Text = "";
            coadaComenzi.Clear();
        }

        private void button_PlaseazaTB_Click(object sender, EventArgs e)
        {
            if (richTextBox_TB.Text.Equals(""))
            {
                MessageBox.Show("Nu aveti produse adaugate in comanda! Va rugam sa adaugati produse!");
            }
            else
            {
                if (_usernameClient != "")
                {
                    coadaComenzi.Enqueue(System.Environment.NewLine + "Comanda de la Taco Bell pentru " + _usernameClient + " este: " + System.Environment.NewLine);
                }
                MessageBox.Show("Comanda dumneavoastra a fost inregistrata cu succes! Va multumim!");
                richTextBox_TB.Text = "";
                //Close();
            }
        }

        // McDonald's si butoane

        private void ComboBoxMC()
        {
            string[] produse = _managerMC.ReturnAll();
            comboBox_MC.Items.Clear();
            for (int i = 0; i < _managerMC.GetNrProduse(); ++i)
            {
                comboBox_MC.Items.Add(produse[i]);

            }
            comboBox_MC.SelectedIndex = 0;
        }

        private void comboBox_MC_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button_AddMC_Click(object sender, EventArgs e)
        {
            string produs = (String)(comboBox_MC.SelectedItem);
            richTextBox_MC.AppendText(String.Format(produs + System.Environment.NewLine));

            coadaComenzi.Enqueue(produs);
        }

        private void richTextBox_MC_TextChanged(object sender, EventArgs e)
        {

        }

        private void button_backToMainMC_Click(object sender, EventArgs e)
        {
            //listPanel[0].BringToFront();
            Parola_Box.Text = "";
            Username_Box.Text = "";

            if (richTextBox_MC.Text.Equals(""))
            {
                listPanel[0].BringToFront();

            }
            else
            {
                MessageBox.Show("Atentie, aveti produse in cos !");
                return;
            }
        }

        private void button_StergeMC_Click(object sender, EventArgs e)
        {
            richTextBox_MC.Text = "";
            coadaComenzi.Clear();
        }

        private void button_PlaseazaMC_Click(object sender, EventArgs e)
        {
            if (richTextBox_MC.Text.Equals(""))
            {
                MessageBox.Show("Nu aveti produse adaugate in comanda! Va rugam sa adaugati produse!");
            }
            else
            {
                if (_usernameClient != "")
                {
                    coadaComenzi.Enqueue(System.Environment.NewLine + "Comanda de la McDonald's pentru " + _usernameClient + " este: " + System.Environment.NewLine);
                }
                MessageBox.Show("Comanda dumneavoastra a fost inregistrata cu succes! Va multumim!");
                richTextBox_MC.Text = "";
                //Close();
            }
        }

        private void label21_Click(object sender, EventArgs e)
        {

        }

        //PANEL CURIER
        private void button_preluare_Click(object sender, EventArgs e)
        {
            if (richTextBox_OS.Text.Equals(""))
            {
                MessageBox.Show("Nu aveti comenzi de preluat!");
            }
            else
            {
                richTextBox_OS.Text = "";
                coadaComenzi.Clear();
                MessageBox.Show("Îți mulțumim pentru servicii! Zi ușoară! ");
               
                //Close();
            }
        }

        private void button_backToMainOS_Click(object sender, EventArgs e)
        {
            listPanel[0].BringToFront();
            Parola_Box.Text = "";
            Username_Box.Text = "";
        }

        private void richTextBox_OS_TextChanged(object sender, EventArgs e)
        {

        }

        private void button_afisareOS_Click(object sender, EventArgs e)
        {
            /*if (stivaComenzi.Count > 0)
            {
                richTextBox_OS.AppendText(String.Format("" + System.Environment.NewLine));
                while (stivaComenzi.Count > 0)
                    richTextBox_OS.AppendText(String.Format(stivaComenzi.Pop() + System.Environment.NewLine));
            }
            */

            if (coadaComenzi.Count > 0)
            {
                
                string[] array = new string[coadaComenzi.Count];
                coadaComenzi.CopyTo(array, 0);       
                richTextBox_OS.AppendText(String.Format("" + System.Environment.NewLine));
                for (int i = array.Length - 1; i >= 0 ; i--)
                  
                    richTextBox_OS.AppendText(String.Format(array[i] + System.Environment.NewLine));
            }
            else
            {
                MessageBox.Show("În acest moment nu sunt comenzi de afisat! Multumim!");
            }
        }
    }
}
